// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
module.exports = [
  require('./no-implicit-descendant'),
  require('./no-motion-outside-of-mixin'),
  require('./license-headers'),
];
