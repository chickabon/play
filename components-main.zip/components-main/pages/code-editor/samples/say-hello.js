function sayHello() {
  console.log('Hello, world!');
}

sayHello();
